========================================================
  SUMMER SCHOOL PROJECT DIRECTORY
  Last modified: 12 August 2026
========================================================

This is the working directory for the Plasmodium
falciparum genomics project — East Africa field sites
2026 cohort.

Directory structure:
  raw_data/     - raw sequencing reads and sample info
  reference/    - reference genome and annotation
  variants/     - variant call files
  results/      - analysis outputs (work in progress)
  logs/         - pipeline run logs
  scripts/      - analysis scripts
  workshop1/    - supplementary workshop materials
