#!/bin/bash
# run_pipeline.sh
# Dr. Kizza's alignment pipeline
# Status: INCOMPLETE

REFERENCE="reference/Pfalciparum_3D7.fasta"
SAMPLES_DIR="raw_data"
RESULTS_DIR="results"

echo "Starting pipeline..."
echo "Reference: $REFERENCE"
echo "Samples directory: $SAMPLES_DIR"
echo "Results directory: $RESULTS_DIR"

# TODO: complete alignment steps
